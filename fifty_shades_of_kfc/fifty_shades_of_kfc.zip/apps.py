from django.apps import AppConfig


class FiftyShadesOfKfcConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'fifty_shades_of_kfc'
