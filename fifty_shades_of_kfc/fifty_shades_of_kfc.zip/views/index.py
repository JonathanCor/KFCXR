__author__ = 'Jonathan Corvers'

from django.shortcuts import render


def index(request):
    return render(request=request, template_name='consumer/index.html')
